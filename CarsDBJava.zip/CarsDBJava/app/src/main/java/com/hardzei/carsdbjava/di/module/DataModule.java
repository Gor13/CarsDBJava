package com.hardzei.carsdbjava.di.module;

import com.hardzei.carsdbjava.model.CarsListModel;

import dagger.Module;
import dagger.Provides;

@Module
public class DataModule {

    @Provides
    public CarsListModel provideModelClass() {
        return new CarsListModel();
    }
}
