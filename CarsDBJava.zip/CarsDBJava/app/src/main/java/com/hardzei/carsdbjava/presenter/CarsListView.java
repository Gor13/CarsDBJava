package com.hardzei.carsdbjava.presenter;

import com.hardzei.carsdbjava.db.Car;

import java.util.List;

public interface CarsListView {
    void showData(List<Car> cars);
}
