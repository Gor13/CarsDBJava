package com.hardzei.carsdbjava.presenter;

import android.content.Context;
import android.util.Log;

import com.hardzei.carsdbjava.MainContract;
import com.hardzei.carsdbjava.db.Car;
import com.hardzei.carsdbjava.db.CarsDatabase;
import com.hardzei.carsdbjava.model.CarsListModel;
import com.hardzei.carsdbjava.view.CarsListActivity;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class CarsListPresenter implements MainContract.PresenterCallBack, MainContract.ModelCallBack.OnFinishedListener {

    private MainContract.ViewCallBack mainView;
    private CarsListModel model;

    CompositeDisposable compositeDisposable;

//    public CarsListPresenter(CarsListActivity activity) {
//        this.activity = activity;
//        carsDatabase = CarsDatabase.getInstance(activity);
//    }

    public CarsListPresenter(MainContract.ViewCallBack mainView, CarsListModel model) {
        this.mainView = mainView;
        this.model = model;
    }

    @Override
    public void onButtonClick() {
        model.getSortedCars(this);
    }

    @Override
    public void onFinished(List<Car> cars) {
        if (mainView != null) {
            mainView.showData(cars);
        }
    }

    @Override
    public void onDestroy() {
        if (compositeDisposable != null)
            compositeDisposable.dispose();
    }
}
