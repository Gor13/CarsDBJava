package com.hardzei.carsdbjava;

import com.hardzei.carsdbjava.db.Car;

import java.util.List;

public interface MainContract {

    interface ViewCallBack {
        void showData(List<Car> cars);
    }

    interface ModelCallBack {
        interface OnFinishedListener {
            void onFinished(List<Car> cars);
        }

        void getSortedCars(OnFinishedListener onFinishedListener);
    }

    interface PresenterCallBack {
        void onButtonClick();

        void onDestroy();
    }
}
