package com.hardzei.carsdbjava.model;

import android.util.Log;

import com.hardzei.carsdbjava.MainContract;
import com.hardzei.carsdbjava.db.Car;
import com.hardzei.carsdbjava.db.CarDao;
import com.hardzei.carsdbjava.db.CarsDatabase;

import java.util.List;
import java.util.concurrent.Executors;

import javax.inject.Inject;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class CarsListModel implements MainContract.ModelCallBack {

  //  private CarDao carDao;

//    @Inject
//    public CarsListModel(CarDao carDao) {
//        this.carDao = carDao;
//        Executors.newSingleThreadScheduledExecutor().execute(new Runnable() {
//            @Override
//            public void run() {
//                carDao.insertCars(List.of(
//                        new Car("Mercedes", "red", 2000, 2234.0, 20000.0),
//                        new Car("BMW", "green", 1992, 2564.0, 33333.0),
//                        new Car("Jeep", "blue", 1500, 4467.0, 444444.0),
//                        new Car("Honda", "pink", 1999, 44367.0, 4443444.0),
//                        new Car("Jeep", "gold", 2030, 5467.0, 554444.0),
//                        new Car("Audi", "black", 2020, 1234.0, 111.0),
//                        new Car("Volga", "white", 2014, 6777.0, 7777.0)));
//            }
//        });
//    }

    @Override
    public void getSortedCars(OnFinishedListener onFinishedListener) {
//        Disposable disposable = carDao
//                .getAllCars()
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(cars -> {
//                    onFinishedListener.onFinished(cars);
//                    Log.d("SUCCESS", String.valueOf(cars.size()));
//                }, throwable -> {
//                    Log.d("ERROR", throwable.getMessage());
//                });
    }
}
