package com.hardzei.carsdbjava.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import io.reactivex.Observable;

@Dao
public interface CarDao {
    @Query("SELECT * FROM cars_table")
    Observable<List<Car>> getAllCars();

    @Query("SELECT * FROM cars_table WHERE id == :movieId")
    Car getCarById(int movieId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertCars(List<Car> movies);

    @Query("DELETE FROM cars_table")
    void deleteAllCars();

    @Insert
    void insertCar(Car car);

    @Delete
    void deleteCar(Car car);
}
