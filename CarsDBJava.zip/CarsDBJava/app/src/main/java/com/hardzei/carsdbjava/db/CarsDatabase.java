package com.hardzei.carsdbjava.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.List;
import java.util.concurrent.Executors;

@Database(entities = {Car.class}, version = 1, exportSchema = false)
public abstract class CarsDatabase extends RoomDatabase {

    public abstract CarDao carDao();

//    private static CarsDatabase INSTANCE;
//    private static final String DB_NAME = "cars.db";
//
//    public synchronized static CarsDatabase getInstance(Context context) {
//        if (INSTANCE == null) {
//            INSTANCE = buildDatabase(context);
//        }
//        return INSTANCE;
//    }
//
//    private static CarsDatabase buildDatabase(final Context context) {
//        return Room.databaseBuilder(context,
//                CarsDatabase.class,
//                DB_NAME)
//                .addCallback(new Callback() {
//                    @Override
//                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
//                        super.onCreate(db);
//                        Executors.newSingleThreadScheduledExecutor().execute(new Runnable() {
//                            @Override
//                            public void run() {
//                                getInstance(context).carDao().insertCars(List.of(
//                                        new Car("Mercedes", "red", 2000, 2234.0, 20000.0),
//                                        new Car("BMW", "green", 1992, 2564.0, 33333.0),
//                                        new Car("Jeep", "blue", 1500, 4467.0, 444444.0),
//                                        new Car("Honda", "pink", 1999, 44367.0, 4443444.0),
//                                        new Car("Jeep", "gold", 2030, 5467.0, 554444.0),
//                                        new Car("Audi", "black", 2020, 1234.0, 111.0),
//                                        new Car("Volga", "white", 2014, 6777.0, 7777.0)));
//                            }
//                        });
//                    }
//                })
//                .build();
//    }
}
