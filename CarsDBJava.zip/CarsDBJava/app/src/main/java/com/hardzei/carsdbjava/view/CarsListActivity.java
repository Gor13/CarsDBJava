package com.hardzei.carsdbjava.view;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hardzei.carsdbjava.InitApplication;
import com.hardzei.carsdbjava.MainContract;
import com.hardzei.carsdbjava.R;
import com.hardzei.carsdbjava.adapters.CarAdapter;
import com.hardzei.carsdbjava.db.Car;
import com.hardzei.carsdbjava.di.component.DaggerActivityComponent;
import com.hardzei.carsdbjava.di.module.MvpModule;
import com.hardzei.carsdbjava.presenter.CarsListPresenter;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CarsListActivity extends AppCompatActivity implements MainContract.ViewCallBack {

    @Inject
    MainContract.PresenterCallBack presenterCallBack;

    @Inject
    Context mContext;

    @Nullable
    @BindView(R.id.searchView)
    SearchView searchView;
    @Nullable
    @BindView(R.id.carsRecyclerView)
    RecyclerView carsRecyclerView;
    @Nullable
    @BindView(R.id.buttonUpdate)
    Button button;
    @Nullable
    @BindView(R.id.sortedSpinner)
    Spinner sortedSpinner;

    private CarAdapter carAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars);

        Application application = (Application) getApplicationContext();
        application.onLowMemory();

        DaggerActivityComponent.builder()
                .appComponent(InitApplication.get(this).component())
                .mvpModule(new MvpModule(this))
                .build()
                .inject(this);

        ButterKnife.bind(this);

        carAdapter = new CarAdapter();
        carsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        carsRecyclerView.setAdapter(carAdapter);

       // carsPresenter = new CarsListPresenter(this);
        presenterCallBack.onButtonClick();

        button.setOnClickListener(v -> presenterCallBack.onButtonClick());
        sortedSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
               switch (position){
                   case 0 : { presenterCallBack.onButtonClick(); }
                   break;
                   case 1 : { }
                   break;
                   case 2 : { }
                   break;
                   case 3 : { }
                   break;
                   case 4 : { }
                   break;
                   case 5 : { }
                   break;
                   case 6 : { }
                   break;
                   case 7 : { }
                   break;
                   case 8 : { }
                   break;
                   case 9 : { }
                   break;
               }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }

    public void showData(List<Car> cars) {
        carAdapter.setCars(cars);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        presenterCallBack.onDestroy();
    }
}